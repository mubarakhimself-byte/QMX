# Resume QMX UI/UX design here

**Latest user decision: study 03 is rejected and withdrawn for layout failure. Stop using BMAD in this UI session.** Aesthetic work remains deferred, but this is not merely a color/style rejection.

Read [layout-fidelity-reset.md](layout-fidelity-reset.md) first. It maps the assistant's specific departures back to original image/text evidence. Then read D-026–D-028 in [decisions.md](decisions.md).

## What must survive compaction
- The user already supplied distinct layouts. Main copilot has sessions/history, conversation and preview. Mini-app has app-specific top navigation, substantial widget canvas and optional right copilot. Do not impose a permanent secondary sidebar or one generic interior on all destinations.
- Shared global rail persists, including platform destinations, divider and opened apps. The selected application changes navigation and working composition.
- Widgets need meaningful charts/tables/controls and detailed expansions. Metadata descriptions and large explanatory banners are not acceptable substitutes. Keep study notes outside the product surface.
- Reopened original OpenBB and VS Code source images and re-read the full bottom dictation in this correction turn. Sources were sufficiently explicit; the failure was in applying them.
- Recent Codex screenshots inform preview/conversation controls, not a replacement app layout. Native Codex control is unavailable; plus menu remains unobserved.
- Library and authoring have greater room for design, not implicit approval. n8n is an explicit authoring reference lead.

## Current status
No corrected replacement mock produced in the rejection turn. Next artifact should reconstruct the original app layout, compare it with the source, demonstrate a second genuinely different app composition, and preserve the separate main-copilot arrangement. Do not describe study 03 as almost done or awaiting cosmetic refinement.

Five recent screenshots are preserved under experience-v03/references. The original storyboard extraction, all 18 web captures and all prototype revisions remain available. Study 02 tokens are rejected; study 03 is historical only. Earlier conversation snapshot ends at kickoff; later decisions/session-log preserve corrections, not a complete transcript export.

Grok implements and continues backend/SDK work. Shared capability/separate conversations remains accepted. No new backend audit, worktree, app implementation, commit, push or final handoff. No live-browser/Reticle verification of the recent studies; the previous file-URL block was not bypassed.

Tracking: canonical `.scratch/qmx-design-wayfinding/` at repository root; portable copy in wayfinding/. No ticket resolved. [Session log](session-log.md) is the chronology.

# QMX UI/UX fresh start — 2026-09-23

This is the working record for the single ongoing design session. **Resume from [CURRENT.md](CURRENT.md)** after compaction. The current stage is interactive design proposals and initial reusable component rules; no final design or implementation is approved or claimed.

## Authority and scope

1. The user's current instructions and corrections.
2. The original Excalidraw storyboard: `C:/Users/Mubarak/Documents/brain/brain/Excalidraw/qmx-ui-storyboard.md`.
3. Inspected images, video, and current reference documentation, with provenance.
4. Actual backend code at an explicitly recorded branch/commit. Implementation documents are supporting evidence, not proof of runtime behavior.

Old BMAD UI/UX decisions are excluded. Do not read or revive them unless the user specifically asks. Existing backend code remains relevant. Do not mistake a fresh design start for permission to delete or rebuild working backend functionality.

## Session constraints

- Keep work in this task; keep decisions, unresolved questions, and evidence in files.
- Use lower-end sub-agents for bounded research/inventory. Escalate only where useful.
- No finalized requirement may silently emerge from a speculative remark in the dictation.
- A user-facing application change must be proven in the running app with Reticle. Only `reticle_act_and_wait` and `reticle_assert` verdicts count; `unknown` is not a pass.
- Initial discovery does not change the running app or claim a Reticle verdict.

## Files

- `session-log.md`: completed actions and resume point.
- `storyboard-reading.md`: intent, visual evidence, and open design choices.
- `backend-grounding.md`: source-grounded capability inventory (agent-owned during initial pass).
- `video-reference.md`: timestamped terminal-demo observations (agent-owned during initial pass).
- `decisions.md`: accepted constraints and proposals clearly separated.
- `reference-research.md`: first-party reference findings and remaining browser research.
- `browser-research-brief.md`: prepared, undispatched Grok/browser-agent prompt for focused interaction research.
- `live-research/grounding-summary.md`: current starting point after the user's correction; broad intent map and live reference findings.
- `live-research/dictation-audit.md`: complete current text, links, attachment inventory, and expanded-view arrow evidence.
- `live-research/`: source-specific browser reports, screenshots, and the current decoded scene in `board-current/`.
- `evidence/`: decoded scene, original text extraction, asset map, review images/video frames, and extraction tooling.

## Current stage

**Current update: study 03 is rejected and withdrawn for departing from the supplied layout. BMAD is excluded from the remainder of this UI session.** Start with [layout-fidelity-reset.md](layout-fidelity-reset.md) and [CURRENT.md](CURRENT.md). The source defines different main-copilot and mini-app layouts; a generic fixed sidebar and text cards are not an acceptable substitute. No corrected replacement was produced in the rejection turn. Historical drafts and evidence remain preserved, not approved. Grok's backend/implementation work remains separate.

The first pass was insufficiently grounded in live references. The second pass read all current text and inspected all seven linked references plus OpenBB in the browser. Start with `live-research/grounding-summary.md`; the earlier one-journey-first proposal is superseded. Discuss the complete workspace and its related design areas before prioritizing a journey. No final layout or technology is selected. Backend evidence remains pinned to a recorded locally visible integration commit, not a running-app verification or freshly fetched remote. Grok's concurrent observability/logging work is outside this pass. Implementation should use an isolated worktree with a deliberately chosen current backend base; none was created in this research turn.

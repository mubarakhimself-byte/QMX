# Decisions and open choices

Use stable IDs. Record who made a decision, its evidence, date, and consequences. Suggestions stay proposals until accepted. Never rewrite a prior decision silently; supersede it with a linked entry.

## Accepted session constraints

| ID | Constraint | Authority |
|---|---|---|
| D-001 | Begin a fresh UI/UX pass; exclude old BMAD UI/UX decisions | User, 2026-09-23 |
| D-002 | Ground design in actual backend behavior and identify additions where needed | User, 2026-09-23 |
| D-003 | Keep a durable record in this one task/session | User, 2026-09-23 |
| D-004 | Prefer lower-end agents for delegated inventory/research | User, 2026-09-23 |
| D-005 | Start by understanding the Excalidraw board, its images, links, and dictation | User, 2026-09-23 |
| D-006 | Prove any eventual user-facing change in the running app using Reticle | Supplied AGENTS.md instructions |

## Proposals, not accepted decisions

| ID | Proposal | Why it is worth testing |
|---|---|---|
| P-001 | Design the main agent workspace and mini-app workspace as related layouts within one shell | Preserves the two modes in the board while giving shared navigation a clear home |
| P-002 | Keep app pages and expanded artifact tabs conceptually separate | Avoids making Overview, Financials, and an opened widget compete as the same kind of navigation item |
| P-003 | **Superseded by D-007:** use one expansion/copilot/library journey first | User corrected that this narrowed the scope before enough reference research |
| P-004 | Define common widget actions and rendering contracts before designing every widget independently | Addresses the user's concern about the number of detailed views |

## Open questions

| ID | Question | Dependency / next evidence |
|---|---|---|
| Q-001 | What happens to visible panels when a mini-app is switched or closed, while preserving the backend's separation of tab closure and durable sessions? | Backend code already says tab close writes nothing to the product session; visual restore and explicit stop actions remain to design |
| Q-002 | Where does an expanded widget/workflow open, and how does the user return? | Preserve the user's top-tab proposal; compare it with the observed Prime switch from matrix to detail within the complete workspace model |
| Q-003 | Does “go to library” locate an existing artifact, save a new result, or both via separate actions? | Actual library identity/search/save operations |
| Q-004 | How are global, app, and widget agent contexts shown and enforced? | Actual backend principal/grant/session controls |
| Q-005 | Which app categories and default apps are needed first? | User's priority work, not copied competitor menus |
| Q-006 | What does a mini-app author have to provide for its pages, widgets and detail views? | Current backend app/workflow implementation and deferred UI contribution points |
| Q-007 | How should workflow/code authoring and app-use change requests connect? | Current lifecycle/authority boundaries |
| Q-008 | Where are global, app, widget and agent settings accessed? | Concrete tasks and scoped configuration operations |
| Q-009 | What do BMS/BIMS and “market sentient” refer to in the dictation? | Clarify when choosing that domain journey |
| Q-010 | Which reference behaviors remain unverified? | Public browser pass completed; signed-in persistence, actual permissions, and most editing/execution flows remain untested. See `live-research/` |

## Afternoon correction — 2026-09-23

- **D-007 (user):** ground the whole design in the complete dictation and actual reference browsing before narrowing to a suggested journey. Supersedes P-003 as the starting sequence.
- **D-008 (user):** take time, explain the design in manageable pieces, and preserve decisions in this session. Do not make the user read a long report to understand progress.
- **C-001 (source correction):** the board explicitly proposes a persistent home showing everything running, a main-menu divider, then opened-app icons. Dynamic app menus differ from expanded widget/workflow views.
- **C-002 (source correction):** the user revises the global-library idea toward navigating back through the sidebar from any mini-app. The exact locate/save operation is still open; a library tab is not a settled requirement.
- **C-003 (evidence):** the expanded-view label, its orange arrow, and the separate eight-arrow screenshot annotation group are present in the current saved scene. The small rectangle at the orange arrow's start is empty; no exact intended image target is established.
- **P-005 (assistant recommendation, not action authorization):** isolate eventual implementation in a new worktree from an agreed current backend base. Existing `ui` is at an older August commit; do not assume it or root `main` is the correct base. User asked for advice, not creation. No new worktree was created.

## Not selected

No frontend framework, design system, rendering technology, navigation hierarchy, library database, or node-editor implementation has been selected in this pass. No application implementation has begun.

## Experience design kickoff — 2026-09-23

- **D-009 (user):** accepts the experience-first direction and authorizes turning the storyboard into new experience drafts across the six areas discussed. This accepts the working direction, not every proposed behavior in v0.1.
- **D-010 (user):** Grok will implement; Codex supplies design guidance, specifications and evidence in this session. Preserve a useful handoff and transcript evidence.
- **D-011 (user):** BMAD architecture is for later, especially to assess backend enhancements. Do not invoke it during this kickoff.
- **D-012 (user preference):** preserve the broad layout as a strong starting point; the user estimates it is around 70% settled. That is not approval of exact geometry, navigation or a measured completion status.
- **D-013 (user):** design for ongoing upgrades and future agents, including the copilot's ability to build apps/widgets/workflows. Establish understandable rules and documentation for this.
- **P-006 (assistant):** build a QMX-owned design system using suitable underlying primitives, plus a separate versioned app contribution contract. No library/framework chosen.
- **P-007 (assistant):** distinguish app composition from workflow-logic editing. A copilot can assist both; graph editing is a tool, and arbitrary code-to-graph round-tripping is not assumed.
- **P-008 (assistant):** the first interactive draft uses app-specific pages and a separate group of detail tabs, per-app retained context and a library return location. These are discussion proposals, not accepted requirements or implemented backend behavior.

Current draft entry: `experience-v01/START-HERE.md`. Open design questions O-01–O-08 are in `experience-storyboard.md`; backend questions B-01–B-09 are in `grok-handoff.md`.

## Shared platform and copilot clarification — 2026-09-23

- **D-014 (user):** Grok is actively expanding core architecture, beyond the previously mentioned observability work. Treat the inspected backend inventory as historical evidence; reconcile requirements with updated code later. Final Grok handoff contents remain revisable.
- **D-015 (user):** platform destinations above the divider exist independently of opened apps; opened apps use those shared capabilities. Do not give each app an isolated copy of Home/Library/Authoring infrastructure.
- **D-016 (user):** explicitly account for json-render and MCP Apps in the design/specification discussion. Their importance does not select their integration architecture automatically.
- **P-009 (assistant responding to the user's alternatives):** one shared platform agent capability with multiple independently scoped sessions, exposed as a broad main workspace and optional app assistant panels. No single all-knowing conversation, mandatory per-app agent process or deployment singleton implied. App panel defaults are configurable; scope/authority stays explicit.
- **P-010 (assistant):** evaluate json-render against the QMX component catalog and MCP Apps for hosted tool-associated interfaces; allow coexistence and custom views. Validate integrations before adoption.

`experience-v01/copilot-and-platform-clarification.md` expands these points and contains a short, unsent coordination note for Grok. The v0.1 inline model's always-visible app copilot is illustrative, not a decision that every app needs one.

## Copilot direction accepted; interaction details added — 2026-09-23

- **D-017 (user):** accepts P-009's shared copilot capability/multiple independently scoped sessions direction, including conversation restoration without merging histories. User reports giving this recommendation to Grok. Exact schemas, deployment and context-retention behavior are not ratified by this acceptance.
- **D-018 (user):** keep this session focused on UI/experience/specifications. Backend implications are expected, but Grok handles ongoing architecture/SDK work; reconcile later.
- **D-019 (user scope addition):** include composer attachments/references and structured user-question interactions in the main workspace design. Cross-project references are relevant; their precise behavior remains to design.
- **C-004 (user-reported):** earlier core work drew on VS Code's extension model; Grok is reportedly implementing SDK enhancements. No new implementation has been inspected by this task.
- **P-011 (assistant):** next deepen the main workspace in five states: start/resume, compose with attachments, reference another context, answer a question, inspect output/continuing work. Preserve the full storyboard and adapt shared patterns to optional app panels afterward.

Next-pass brief: `experience-v01/main-workspace-next-pass.md`. App-to-app/workflow communication is a recorded coordination concern, not a transport decision in this session.

## Portable design process — 2026-09-23

- **D-020 (user):** continue design proposals with discretion over medium; everything must be transferable and durable through compaction. Minimize questions. Grok's handoff is not imminent; broader design remains unfinished.
- **P-012 (assistant):** use self-contained HTML behavior studies, companion Markdown contracts/evidence, and draft semantic tokens. Keep a small local Wayfinder decision map. Develop UX and design-system rules together, then consolidate after app/detail, Library and authoring studies.
- **P-013 (assistant):** study 02 proposes next-message versus conversation context, preserved pending questions/drafts per conversation, and an explicit unavailable-source state. Theme, exact geometry, scope defaults and recovery behavior are not approved.
- **C-005 (verification):** browser policy blocked the study 02 local-file URL. No workaround attempted. JavaScript syntax and package checks are separate from browser interaction proof; no Reticle verdict or production readiness is claimed.

Current working artifacts: `experience-v02/README.md`; short resume entry: `CURRENT.md`. The first Wayfinder prototype ticket remains claimed awaiting reaction, not resolved by authorization to draft.

## User review and app/Library direction — 2026-09-23

- **D-021 (user):** rejects study 02's colors/rendering and defers aesthetics/component-system selection. Do not promote its tokens or new wireframe scaffolding into the QMX visual system. User supplies most of the broad layout grounding.
- **D-022 (user):** attachment picker needs revision; attached-item appearance/concept is useful. Explain what dataset/app attachments actually mean. Use Codex's plus-menu/plugin logic as a research reference; existing cross-app proposal is reopened, not ratified.
- **D-023 (user):** show a mini-app and Library next. Question interaction can work; preview concept is useful, with preference for Codex's tabbed work area. Neither statement approves all previous behavior details.
- **D-024 (source addition):** five supplied screenshots are saved under `experience-v03/references/`. Red-circled control is a candidate conversation navigator; exact official name and interactions are unverified. No screenshot shows the expanded plus menu. Native Codex control is unavailable in the current tool.
- **D-025 (user):** inspect BMAD UX for design-system guidance while the user looks for another system. This does not authorize selecting a new aesthetic direction or finalizing a formal UX specification.
- **P-014 (assistant):** study 03 models typed Library resources, source/version inspector, separate file/resource/tool selection paths, a Research mini-app, and a tabbed work area. Catalogue structure and exact attachment semantics remain proposals.
- **C-006 (research):** installed local plugin manifests establish packages can bundle skills/connectors/MCP components; they do not establish plus-menu behavior. Do not equate plugin, external connected app and QMX mini-app automatically.

Current entry: `experience-v03/README.md`. No new backend/SDK audit, architecture decision, plugin installation or actual tool invocation resulted from this design pass.

## Layout rejection and source fidelity — 2026-09-23

- **D-026 (user):** rejects study 03 as a material departure from the defined layout, not merely unattractive styling. Mini-app interiors must change with the application. Re-ground in the original OpenBB/VS Code images and dictation; do not substitute generic text cards or impose the main-agent layout on mini-apps.
- **D-027 (user):** stop using BMAD in this UI session. Supersedes D-025's permission to inspect BMAD UX as a workflow direction. The assistant owns the failed design decisions; the skill is not an excuse.
- **D-028 (user):** Library and authoring had greater room for exploration, but neither study 03 Library nor authoring placeholders are approved. n8n is an explicit authoring reference lead.
- **C-007 (assistant audit):** original source visibly has dynamic top app navigation, a space-efficient widget canvas with meaningful data views, and copilot beside it. The prototype's fixed secondary sidebar and prose-heavy cards were unsupported departures. Recent Codex screenshots must not displace the original app reference.
- **P-015 (assistant corrective standard):** next reconstruct the source app layout faithfully, compare side by side, demonstrate a second genuinely different app composition, and keep explanations outside the app surface. Exact colors, detailed expansion behavior and Library taxonomy remain undecided.

Current entry is now `layout-fidelity-reset.md`. Study 03 is withdrawn, not accepted or cosmetically awaiting refinement.
